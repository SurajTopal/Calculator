/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.Scanner;
/**
 *
 * @author SURAJ SINGH
 */

class StackInfix
  {
     int top;
	 int size;
	 char s[]; 
         String op[];   // String array to store operand...
    void push(char ch)
  {
     if(top==size-1)
	 {
		 System.out.println("Stack is Full..");
	 }
	 else
	 {
		 top++;
		 s[top]=ch;
	 }
  }
  
  void display()
  {
	  if(top==-1)
		  System.out.println("Stack is Empty..");
	  else
	  {
		  System.out.println("\nStack Element..");
		  for(int i=0;i<=top;i++)
		  {
			  System.out.println(s[i]);
		  }
	  }
  }
 
   char pop()
  {

	  char p='N';
     if(top==-1)
	 {
		 System.out.println("Stack is Empty..");
	 }
	 else
	 {
		 p=s[top];
		 s[top]='0';
          top--;		 
	 }
	 return p;
  }
  

boolean optr(char ch)
   {
	   if(ch=='+' || ch=='-' || ch=='*' || ch=='/' || ch=='^' || ch=='(' || ch==')')
	   {
		   return true;
	   }
	   else
		   return false;
   }
   
  String[] convertInfixToPost(String str)
  {
	  String postfix[]=new String[size];
	  int i=0;
	  int k=-1;
          
          boolean num=false;
	  StackEvaluation obj=new StackEvaluation();
	  while(i<str.length())
	  {
		  if(top==-1 && optr(str.charAt(i)))
          {
                         num=false;
			  push(str.charAt(i++));
		      display();
		  }			  
		  else
		  {
			  if(optr(str.charAt(i)))
			  {
                              num=false;
				  if((obj.outStackPre(str.charAt(i)) < obj.inStackPre(s[top])) && str.charAt(i)==')')
				  {
                                          k++;
					  postfix[k]=""+pop();
                                          pop();
					  i++;
                                         
				  }
				  else if(obj.outStackPre(str.charAt(i)) < obj.inStackPre(s[top]))
				  {
                                          k++;
					  postfix[k]=""+pop();
				  }
				  else
				  {
					  push(str.charAt(i++));
					  display();
				  }
			  }
			 else
	   	     {
			  
                          if(num==true)
                          {
                            postfix[k]=postfix[k]+str.charAt(i);
                            i++;
                          }
                          else
                          {
                             k++;
                             postfix[k]=""+str.charAt(i++);
                          }
                          
                          num=true;
		     }
		  }	
	  }
	System.out.println("Top : "+top);
	
	  while(top >=0)
	  { 
              
              postfix[++k]=""+pop();
	  }
          
          System.out.println("PostFix : - ");
          for( i=0;i<postfix.length && postfix[i]!=null;i++)
          {
              System.out.println(postfix[i]);
          }        
	  return postfix;
  }
 }
