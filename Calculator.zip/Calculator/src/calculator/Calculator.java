/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author SURAJ SINGH
 */
public class Calculator 
{  
    String  calculation(String result)
    {
      StackInfix obj=new StackInfix();
        //CalculatorGui object=new CalculatorGui();
        //object.setVisible(true);
	   obj.top=-1;
	   obj.size=50;
	   obj.s=new char[obj.size];
	   System.out.println("Top : "+obj.top);
	   System.out.println("Size : "+obj.size);
	   System.out.println(obj.s.length);
           Scanner scan=new Scanner(System.in);

	   String postfix[]=obj.convertInfixToPost(result);

          
          System.out.println("OUPUT : -----");
          
          int i;
          for( i=0;postfix[i]!=null;i++)
          {
            System.out.println(" "+postfix[i]);
          }
          System.out.println("i value : "+i);
          String postfix1[]=new String[i];
          for(i=0;i<postfix1.length;i++)
          {
              postfix1[i]=postfix[i];
          }
	   StackEvaluation obj1=new StackEvaluation();
	   obj1.top=-1;
	   obj1.size=obj.size;
	   obj1.s=new float[obj.size];
	   float result1=obj1.stackEvaluation(postfix1);
	   System.out.println("Result : "+result1); 
           NumberFormat nf=NumberFormat.getInstance(new Locale("en","ENGLISH"));
          
           return ""+nf.format(result1);
    }
    
}
