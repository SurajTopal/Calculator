/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author SURAJ SINGH
 */
 
 class StackEvaluation
 {
    int top;
    int size;
    float s[];	
    static int count=0;
   static String msg="Message";
	 void display()
  {
	  if(top==-1)
		  System.out.println("Stack is Empty..");
	  else
	  {
		  System.out.println("\nStack Element..");
		  for(int i=0;i<=top;i++)
		  {
			  System.out.println(s[i]);
		  }
	  }
  }
   
    void push(float no)	
	{
	    if(top==size-1)
        {
			System.out.println("Stack is Full..");
		}			
		else
	    {
			top++;
			s[top]=no;
		}
	}	
 float pop()
 {
	 float val=0; // changes done ... here 
	 if(top==-1)
	 {
		 System.out.println("Stack is Empty..");
	 }
	 else
	 {
		val=s[top];
        s[top]=-1;
        top--; 		
	 }
	 return val;
	 
 }	 
  boolean operand(char ch)
  {
	  if(ch=='+' || ch=='-' || ch=='*' || ch=='/' || ch=='^')
		   return true;
	   else
		   return false;
  }
 	 
	 float operation(char ch)
	 {
             float no2=0,no1=0;
                 if(top!=-1)
                     no2=pop();             
                 else
                     msg="Something Went Wrong";
                 
                     if(top!=-1) 
                         no1=pop();
                     else
                      msg="Something Went Wrong";
                  
		 System.out.println("no1 : "+no1+"  no2 : "+no2+"    operation : "+ch);
		 switch(ch)
		 {
			 case '+' : return no1+no2;
			 case '-' : return no1-no2;
			 case '*' : return no1*no2;
			 
			 case '/' : 
			              float result=0;
			              try
						  {
			              result=no1/no2;
			              }
                           catch(Exception e )
						   { System.out.println("Exception : "+e);}						   
						  return result;
			 
			 case '^' : return (float)Math.pow(no1,no2);
		 }
		 return 0;
	 }
	 
	 
         
    	 int inStackPre(char ch)
	 {
	 if(ch=='+' || ch=='-')
		  return 2;
	  else if(ch=='*' || ch=='/')
		  return 4;
	  else if(ch=='^')
		  return 5;
	  else
		  return 0;
	 }
 
		  int outStackPre(char ch)
	{
		if(ch=='+' || ch=='-')
		  return 1;
		else if(ch=='*' || ch=='/')
		  return 3;
		else if(ch=='^')
		  return 6;
		else if(ch=='(')
		  return 7;
		else   
		  return 0;  
	}
     
	 float stackEvaluation(String postfix[])
	 {
             try
               {
                 for(int i=0;i<postfix.length;i++)
		 {
			 
                                if(operand(postfix[i].charAt(0)))
                                  {
                                          push(operation(postfix[i].charAt(0)));
                                  }
                                  else
                                  {                            
                                          push(Float.parseFloat(postfix[i]));
                                   }
                        
		 }
		}
                catch(Exception e )
                             {
                                 System.out.println("Exception : "+e);
                                 msg="Wrong Input";
                                 count++;
                             }
                 if(count>=1 || top==-1)
                 {
                     count=0;   
                     return 0;
                 }
                     return s[top];
             	 }
                
 }
 